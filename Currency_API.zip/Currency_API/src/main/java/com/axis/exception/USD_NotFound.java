package com.axis.exception;

public class USD_NotFound extends RuntimeException{
	String message;

	
	public USD_NotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


	public String getMessage() {
		return message;
	}


	

	
	

}
