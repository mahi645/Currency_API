package com.axis.utils;

public class AppConstant {

	public static final String DateNotFound="Date not found";
	public static final String DELETE_MSG="Currency has deleted successfully";
	public static final String ADD_MSG="Currency has added successfully";
	public static final String UPDATE_MSG="Currency has updated successfully";
	public static final String DATE_FOUND_MSG="Currency Existed with this date";
	public static final String USD_NOT_FOUND_MSG="Currency type should be  in USD ";
	
	

}
